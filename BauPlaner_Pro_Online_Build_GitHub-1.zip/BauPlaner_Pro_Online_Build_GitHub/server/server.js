import express from "express";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import OpenAI from "openai";
import { fileURLToPath } from "url";

const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);
const app=express();
const PORT=process.env.PORT||3000;
const DB=path.join(__dirname,"invites.json");
const ai=process.env.OPENAI_API_KEY?new OpenAI({apiKey:process.env.OPENAI_API_KEY}):null;

app.use(express.json({limit:"50mb"}));
app.use(express.static(__dirname));

function loadDb(){try{return JSON.parse(fs.readFileSync(DB,"utf8"))}catch{return{}}}
function saveDb(db){fs.writeFileSync(DB,JSON.stringify(db,null,2),"utf8")}

app.post("/api/invite",(req,res)=>{
  const snap=req.body;
  if(!snap?.person?.id)return res.status(400).json({error:"Ungültige Mitarbeiterdaten."});
  const token=crypto.randomBytes(24).toString("hex");
  const db=loadDb();db[token]={...snap,createdAt:new Date().toISOString()};saveDb(db);
  res.json({token});
});

app.get("/api/invite/:token",(req,res)=>{
  const db=loadDb(),snap=db[req.params.token];
  if(!snap)return res.status(404).json({error:"Freigabe nicht gefunden."});
  res.json(snap);
});

app.post("/api/invite/:token/time",(req,res)=>{
  const db=loadDb(),snap=db[req.params.token];
  if(!snap)return res.status(404).json({error:"Freigabe nicht gefunden."});
  const {projectId,date,from,to,breakMin,hours,note}=req.body||{};
  const pr=(snap.projects||[]).find(p=>p.id===projectId);
  if(!pr)return res.status(404).json({error:"Baustelle nicht gefunden."});
  const entry={id:"rt"+Date.now()+crypto.randomBytes(3).toString("hex"),personId:snap.person.id,date,from,to,breakMin:+breakMin||0,hours:+hours||0,rate:0,note:note||"",source:"employee",status:"submitted"};
  pr.timeEntries=pr.timeEntries||[];pr.timeEntries.push(entry);saveDb(db);res.json({entry});
});

app.post("/api/estimate",async(req,res)=>{
  try{
    if(!ai)return res.status(503).json({error:"OPENAI_API_KEY fehlt auf dem Server."});
    const {project,images,priceLevel}=req.body||{};
    const content=[{type:"input_text",text:`Du bist Kalkulationsassistent für einen deutschen Erdbau-/Tiefbau-/GaLaBau-Betrieb.
Erstelle aus Beschreibung, Maßen und ggf. Bildern einen konservativen, plausiblen ANGEBOTS-KALKULATIONSVORSCHLAG.
Keine Maße aus Bildern erfinden. Unklare Punkte als Hinweis ausgeben.
Berücksichtige soweit relevant: Baustelleneinrichtung, Aushub, Laden, Entsorgung, Transport, Frostschutz/Schotter, Splitt, Beton, Borde, Drainage, Rohre, Pflastermaterial, Pflasterverlegung, Verdichtung, Maschinenstunden, Personal/Nebenarbeiten, Zuschnitt, Feinplanum, An-/Abfahrt.
Projekt: ${JSON.stringify(project)}
Preisniveau-Faktor: ${priceLevel||1}
Antworte ausschließlich als JSON:
{"positions":[{"name":"...","qty":1,"unit":"...","unitPrice":100,"group":"...","note":"..."}],"notes":["..."]}
Einheitspreise sind grobe marktübliche Netto-Orientierungswerte Deutschland 2026 und müssen bearbeitbar bleiben.`}];
    for(const img of (images||[]).slice(0,4)){if(img)content.push({type:"input_image",image_url:img})}
    const response=await ai.responses.create({model:process.env.OPENAI_MODEL||"gpt-5-mini",input:[{role:"user",content}]});
    let txt=response.output_text||"";
    txt=txt.replace(/^```json\s*/i,"").replace(/```$/,"").trim();
    const data=JSON.parse(txt);
    res.json(data);
  }catch(e){res.status(500).json({error:e?.message||"KI-Kalkulation fehlgeschlagen."})}
});

app.listen(PORT,()=>console.log(`BauPlaner Pro Server läuft auf ${PORT}`));
