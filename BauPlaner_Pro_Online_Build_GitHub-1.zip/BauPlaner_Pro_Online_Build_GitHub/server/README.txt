Für echte KI-Bildkalkulation und Mitarbeiter-Zeiten muss dieser Server öffentlich per HTTPS gehostet werden.
Umgebungsvariablen:
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5-mini
PORT=3000
Dann in der App die Server-Adresse bei KI-Kalkulation bzw. Mitarbeiterzugang eintragen.
