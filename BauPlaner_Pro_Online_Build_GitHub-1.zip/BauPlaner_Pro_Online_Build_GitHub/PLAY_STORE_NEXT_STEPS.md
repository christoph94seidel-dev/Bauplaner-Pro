# Nächste Schritte für Google Play

1. App auf mehreren Android-Geräten testen.
2. Cloud-/Login-System statt rein lokaler Daten finalisieren.
3. Datenschutzerklärung und Impressum einbauen.
4. Mitarbeiterrechte und Datensynchronisierung finalisieren.
5. KI-Backend sicher hosten.
6. Play-Billing für kostenpflichtige Abos integrieren.
7. Release-Key erzeugen und sicher sichern.
8. Signiertes `.aab` erzeugen.
9. Play-Console-Testtrack verwenden.
10. Danach Veröffentlichung beantragen.
