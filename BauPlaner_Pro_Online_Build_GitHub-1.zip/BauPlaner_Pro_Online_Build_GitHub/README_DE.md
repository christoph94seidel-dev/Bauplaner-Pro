# BauPlaner Pro – Android App

Dieses Projekt ist eine native Android-Hülle für die BauPlaner-Pro-Webapp.

## Enthalten
- echtes Android-App-Paket `de.bauplaner.pro`
- App-Icon
- Galerie-/Bildauswahl
- GPS-Berechtigung
- Google-Maps-Links werden extern geöffnet
- lokale Speicherung der bestehenden App-Daten
- Ziel-SDK 36

## So baust du eine APK

1. Android Studio installieren.
2. Diesen Ordner in Android Studio über **Open** öffnen.
3. Warten, bis Gradle Sync abgeschlossen ist.
4. Falls Android Studio nach SDK 36 fragt, installieren lassen.
5. Handy per USB verbinden und USB-Debugging aktivieren.
6. Auf **Run ▶** klicken, um BauPlaner Pro direkt auf dem Handy zu installieren.

### APK-Datei erstellen
**Build → Build App Bundle(s) / APK(s) → Build APK(s)**

### Für Google Play
**Build → Generate Signed Bundle / APK → Android App Bundle**

Für Google Play brauchst du später einen sicheren Signing-Key. Den niemals verlieren.
