BauPlaner Pro 1.1 – geplante Monetarisierung

FREE:
- bis 2 aktive Baustellen
- Fuhrpark / Personal Basis
- einfache Fotos / Navigation

PRO:
- unbegrenzte Baustellen
- automatische Angebotskalkulation
- erweiterter 3D-/Lageplan
- GPS-Aufmaß
- PDF/Angebot später

TEAM:
- Mitarbeiterzugänge
- Mitarbeiter-Zeiterfassung
- Synchronisierung
- Rollen und Rechte

AI ADD-ON:
- Baustellenbilder analysieren
- automatische Kalkulation aus Beschreibung + Maßen + Bildern
- KI-Problemlöser

Vor Play Store:
- Google Play Billing integrieren
- Cloud-Login / Firma / Rollen finalisieren
- Datenschutz / AGB
- Release-Signing
- Closed Test falls persönliches Entwicklerkonto betroffen
