# BauPlaner Pro – Online Android Build

Diese Variante ist für den Build **ohne Android Studio** vorbereitet.

Der GitHub-Actions-Workflow:
- richtet Java 17 ein,
- installiert Android SDK 36,
- verwendet Gradle 8.13,
- baut `:app:assembleDebug`,
- lädt die fertige APK als GitHub-Artifact hoch.

Siehe `ONLINE_BUILD_SMARTPHONE.md` für die Anleitung vom Smartphone.
