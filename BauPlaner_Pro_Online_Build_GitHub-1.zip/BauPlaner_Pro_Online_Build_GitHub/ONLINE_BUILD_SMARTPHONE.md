# BauPlaner Pro – APK direkt online bauen

Du brauchst dafür **keinen PC** und **kein Android Studio**.

## Einmalig: GitHub-Konto
Falls du noch kein GitHub-Konto hast:
1. Öffne github.com auf deinem Smartphone.
2. Kostenlos registrieren und anmelden.

## Projekt hochladen
Am einfachsten geht es über die GitHub-Webseite im Browser:

1. Auf GitHub oben rechts **+** → **New repository**.
2. Name z. B. `bauplaner-pro`.
3. Repository auf **Private** stellen.
4. **Create repository**.
5. Danach **Add file → Upload files**.
6. Lade den **Inhalt dieses Ordners** in das Repository hoch.
   Wichtig: `.github/workflows/build-apk.yml` muss mit hochgeladen werden.
7. Unten **Commit changes** drücken.

Wenn dein Smartphone das Hochladen kompletter Ordner nicht komfortabel unterstützt, entpacke das Paket mit einer Dateimanager-App, die Ordnerstrukturen beibehält, oder lade die Dateien in mehreren Schritten hoch.

## APK bauen
Sobald alles bei GitHub ist:

1. Repository öffnen.
2. Oben **Actions** auswählen.
3. Links **Build BauPlaner Pro APK** öffnen.
4. **Run workflow** → **Run workflow** drücken.
5. Warten, bis der Lauf grün ✅ wird.
6. Den fertigen Lauf öffnen.
7. Ganz unten unter **Artifacts** auf **BauPlaner-Pro-APK** tippen.
8. ZIP herunterladen und entpacken.
9. Darin liegt `app-debug.apk`.
10. APK auf dem Android-Handy öffnen und installieren.

Android kann beim ersten Mal fragen, ob dein Browser/Dateimanager Apps aus unbekannten Quellen installieren darf. Diese Freigabe gilt nur für die von dir verwendete Quelle.

## Wenn wir die App aktualisieren
Neue Dateien bei GitHub hochladen bzw. vorhandene ersetzen. Danach startet bei Änderungen auf `main` automatisch ein neuer APK-Build. Alternativ kannst du jederzeit über **Actions → Run workflow** manuell bauen.

## Später Play Store
Die Debug-APK ist zum Testen. Für den Play Store bauen wir später einen signierten Release-Build als `.aab` und hinterlegen den Signing-Key sicher als GitHub Secret.
