package de.bauplaner.pro;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;

import com.android.billingclient.api.*;
import java.util.ArrayList;
import java.util.List;
import android.widget.Toast;

public class MainActivity extends Activity implements PurchasesUpdatedListener {

    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int LOCATION_PERMISSION_REQUEST = 1002;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private BillingClient billingClient;
    private ProductDetails proProductDetails;
    private static final String PRO_SUBSCRIPTION_ID = "bauplaner_pro";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        webView.addJavascriptInterface(new BillingBridge(), "AndroidBilling");
        setupBilling();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost() == null ? "" : uri.getHost();

                if (host.contains("google.com") || host.contains("google.de") ||
                    host.contains("maps.google") || uri.toString().startsWith("geo:")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                        return true;
                    } catch (Exception ignored) {
                    }
                }

                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {

            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallbackNew,
                    FileChooserParams fileChooserParams) {

                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }

                filePathCallback = filePathCallbackNew;

                Intent intent = fileChooserParams.createIntent();
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this,
                            "Galerie konnte nicht geöffnet werden.",
                            Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin,
                    GeolocationPermissions.Callback callback) {

                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(
                            new String[]{
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                            },
                            LOCATION_PERMISSION_REQUEST
                    );
                }
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void setupBilling() {
        PendingPurchasesParams pending = PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts().build();
        billingClient = BillingClient.newBuilder(this)
                .setListener(this)
                .enablePendingPurchases(pending)
                .build();
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    queryProProduct();
                    refreshPurchases();
                }
            }
            @Override public void onBillingServiceDisconnected() { }
        });
    }

    private void queryProProduct() {
        QueryProductDetailsParams.Product product = QueryProductDetailsParams.Product.newBuilder()
                .setProductId(PRO_SUBSCRIPTION_ID)
                .setProductType(BillingClient.ProductType.SUBS)
                .build();
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(java.util.Collections.singletonList(product)).build();
        billingClient.queryProductDetailsAsync(params, (result, detailsResult) -> {
            List<ProductDetails> list = detailsResult.getProductDetailsList();
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && list != null && !list.isEmpty()) {
                proProductDetails = list.get(0);
            }
        });
    }

    private void refreshPurchases() {
        if (billingClient == null || !billingClient.isReady()) return;
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.SUBS).build();
        billingClient.queryPurchasesAsync(params, (result, purchases) -> {
            boolean active = false;
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                for (Purchase purchase : purchases) {
                    if (purchase.getProducts().contains(PRO_SUBSCRIPTION_ID) &&
                            purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                        active = true;
                        acknowledgeIfNeeded(purchase);
                    }
                }
            }
            sendProState(active);
        });
    }

    private void acknowledgeIfNeeded(Purchase purchase) {
        if (!purchase.isAcknowledged()) {
            AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.getPurchaseToken()).build();
            billingClient.acknowledgePurchase(params, result -> { });
        }
    }

    private void launchProPurchase(String plan) {
        if (proProductDetails == null) {
            queryProProduct();
            Toast.makeText(this, "Abo wird geladen. Bitte gleich noch einmal versuchen.", Toast.LENGTH_SHORT).show();
            return;
        }
        List<ProductDetails.SubscriptionOfferDetails> offers = proProductDetails.getSubscriptionOfferDetails();
        if (offers == null || offers.isEmpty()) return;
        ProductDetails.SubscriptionOfferDetails chosen = null;
        String wanted = "yearly".equals(plan) ? "yearly" : "monthly";
        for (ProductDetails.SubscriptionOfferDetails offer : offers) {
            if (wanted.equalsIgnoreCase(offer.getBasePlanId())) { chosen = offer; break; }
        }
        if (chosen == null) chosen = offers.get(0);
        BillingFlowParams.ProductDetailsParams pd = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(proProductDetails)
                .setOfferToken(chosen.getOfferToken()).build();
        BillingFlowParams flow = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(java.util.Collections.singletonList(pd)).build();
        billingClient.launchBillingFlow(this, flow);
    }

    @Override public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase p : purchases) acknowledgeIfNeeded(p);
            refreshPurchases();
        }
    }

    private void sendProState(boolean active) {
        if (webView == null) return;
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.setBauPlanerProState && window.setBauPlanerProState(" + active + ");", null));
    }

    public class BillingBridge {
        @JavascriptInterface public void buyMonthly() { runOnUiThread(() -> launchProPurchase("monthly")); }
        @JavascriptInterface public void buyYearly() { runOnUiThread(() -> launchProPurchase("yearly")); }
        @JavascriptInterface public void restorePurchases() { runOnUiThread(() -> refreshPurchases()); }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) {
            return;
        }

        Uri[] results = null;

        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) {
                    results[i] = data.getClipData().getItemAt(i).getUri();
                }
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }

        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST && pendingGeoCallback != null) {
            boolean granted =
                    grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED;

            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;

            if (!granted) {
                Toast.makeText(this,
                        "GPS-Berechtigung wurde nicht erteilt.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
