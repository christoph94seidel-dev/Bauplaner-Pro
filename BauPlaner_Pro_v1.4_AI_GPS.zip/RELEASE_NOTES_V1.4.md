# BauPlaner Pro 1.4.0

- KI-Kalkulation: Maße aus Freitext, deterministische Mengenformeln, Materialreserven, klare Rückfragen bei fehlenden Maßen.
- KI-Server: `/api/estimate` extrahiert nur sichere Parameter; Mengen werden in der App berechnet.
- KI-Problemlöser: neuer `/api/ask`-Endpunkt mit Fotoanalyse, Projektkontext und Rückfragen/Chatverlauf.
- GPS-Aufmaß: Mehrfachmessung statt Einzel-Fix, Genauigkeitsfilter, gewichtete Stabilisierung und Warnung bei Strecken innerhalb der GPS-Messunsicherheit.
- Version auf 1.4.0 / versionCode 6 erhöht.

Hinweis: Für KI-Funktionen muss auf dem Server `OPENAI_API_KEY` gesetzt sein. Der API-Key gehört niemals in die Android-App.
